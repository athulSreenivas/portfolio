const degrees = [
  {
    school: 'College Of Engineering Chengannur',
    degree: 'Master Of Computer Application',
    link: 'https://ceconline.edu/',
    year: 2024,
  },
  {
    school: 'Nss College Rajakumari',
    degree: 'Bachelor Of Computer Application',
    link: 'https://www.nsscrky.ac.in/',
    year: 2020,
  },
];

export default degrees;
