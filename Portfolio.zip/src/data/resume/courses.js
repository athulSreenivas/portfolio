const courses = [
  {
    title: 'Python Programming  From A-Z',
    number: 'P',
    link: 'https://www.udemy.com/course/learn-python-programming-from-a-z/?couponCode=LETSLEARNNOWPP',
    university: 'Udemy',
  },
  {
    title: 'The Joy of computing using python',
    number: 'noc21_cs32',
    link: 'https://onlinecourses.nptel.ac.in/noc21_cs32/preview',
    university: 'IIT Kharapur (NPTEL)',
  },
  {
    title: 'Programming in java',
    number: 'noc22_cs47',
    link: 'https://onlinecourses.nptel.ac.in/noc22_cs47/preview',
    university: 'IIT Kharapur (NPTEL)',
  }
];

export default courses;
